function filterAndTransform(arr){
return arr 
.filter(num => num>=0)
.map (num => num * 2)
.sort((a,b) => a - b);
}
const numberal =[-3 ,2,-1,5,0,-4 ,3];
console.log(filterAndTransform(numberal));