function isplaindrome (str){
    let resvers_str= "";
for(let i =str.lenght-1;i>=0;i--){
    resvers_str = reverse_str+str[i];
}
if(str === resvers_str){
    console.log("Its a plaindrome word")
}else{
    console.log("Its not a plaindrome word")
}
}
isplaindrome("madam")
isplaindrome("javascript")
isplaindrome("racecar")

